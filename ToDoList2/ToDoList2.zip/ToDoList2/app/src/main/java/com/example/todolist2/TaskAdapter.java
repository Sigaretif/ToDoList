package com.example.todolist2;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskHolder> {

    private List<Task> tasks = new ArrayList<>();

    @NonNull
    @Override
    public TaskHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item, viewGroup, false);
        return new TaskHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskHolder taskHolder, int i) {
        Task currentTask = tasks.get(i);
        taskHolder.title.setText(currentTask.getTitle());
        taskHolder.category.setText(currentTask.getCategory());
        taskHolder.description.setText(currentTask.getDescription());
        taskHolder.startDate.setText(currentTask.getStart());
        taskHolder.endDate.setText(currentTask.getEnd());
        if(currentTask.getFinished()){
            taskHolder.isDone.setVisibility(View.VISIBLE);
        }
        else{
            taskHolder.isDone.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public int getItemCount() {
        return tasks.size();
    }

    public void setTasks(List<Task> tasks){
        this.tasks = tasks;
        notifyDataSetChanged();
    }

    class TaskHolder extends RecyclerView.ViewHolder{
        private TextView title;
        private TextView description;
        private TextView category;
        private TextView startDate;
        private TextView endDate;
        private ImageView isDone;

        public TaskHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title);
            description = itemView.findViewById(R.id.description);
            category = itemView.findViewById(R.id.category);
            startDate = itemView.findViewById(R.id.startDate);
            endDate = itemView.findViewById(R.id.endDate);
            isDone = itemView.findViewById(R.id.isDoneCheck);
        }
    }
}
